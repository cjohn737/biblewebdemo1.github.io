
  # Bible Web App Wireframe

  This is a code bundle for Bible Web App Wireframe. The original project is available at https://www.figma.com/design/R3P7wMCkJlmKEKcYMdEbxE/Bible-Web-App-Wireframe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  